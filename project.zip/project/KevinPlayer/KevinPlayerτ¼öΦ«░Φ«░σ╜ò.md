```shell
https://www.jianshu.com/p/212c61cac89c

下载ffmpeg
wget xxxxxxx

解压ffmpeg，最新版本：
tar jxvf ffmpeg-4.2.1.tar.bz2

进入ffmpeg，首次编译一遍，后续才能正常使用：
./configure --disable-x86asm

git的安装：
yum install git
git -version

在GitHub中下载，rtmp源码：
下载librtmp，目的是想让ffmpeg集成librtmp，这样才能完成直播相关的功能：
git clone https://github.com/yixia/librtmp.git

文档：班级服务器相关.note
链接：http://note.youdao.com/noteshare?id=9c6be88a1a5d657632dbde6e74a3930b

重新复制一个文件，在当前目录下：
cp /root/KevinStudyNDK/MyFFmpeg/ffmpeg-4.2.1/build.sh /root/KevinStudyNDK/MyFFmpeg/ffmpeg-4.2.1/build_rtmp.sh


```



```
  libavformat/librtmp.c:315: error: undefined reference to 'RTMP_Socket'
  libavformat/librtmp.c:305: error: undefined reference to 'RTMP_SendSeek'
  libavformat/librtmp.c:286: error: undefined reference to 'RTMP_Pause'
  libavformat/librtmp.c:78: error: undefined reference to 'RTMP_Close'
  libavformat/librtmp.c:264: error: undefined reference to 'RTMP_Write'
  libavformat/librtmp.c:275: error: undefined reference to 'RTMP_Read'
  libavformat/librtmp.c:112: error: undefined reference to 'RTMP_LogSetLevel'
  libavformat/librtmp.c:113: error: undefined reference to 'RTMP_LogSetCallback'
  libavformat/librtmp.c:225: error: undefined reference to 'RTMP_Init'
  libavformat/librtmp.c:226: error: undefined reference to 'RTMP_SetupURL'
  libavformat/librtmp.c:232: error: undefined reference to 'RTMP_EnableWrite'
  libavformat/librtmp.c:234: error: undefined reference to 'RTMP_Connect'
  libavformat/librtmp.c:234: error: undefined reference to 'RTMP_ConnectStream'
  libavformat/librtmp.c:254: error: undefined reference to 'RTMP_Close'
  clang++.exe: error: linker command failed with exit code 1 (use -v to see invocation)
  ninja: build stopped: subcommand failed.
```



